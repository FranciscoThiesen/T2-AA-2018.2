 The graphs are given in edge format, i.e. edges are speci-
 fied by pairs of end nodes assuming nodes to be numbered
 1 to <n>, therefore edges may  be considered as directed
 or undirected. Files "*d.rmf" contain double edges, i.e.
 they contain arcs (v,w) and (w,v), other files have been
 generated from *d.rmf-files by eliminating double edges.

 Descriptor items in sequence of lines in file: 

   <n> -  number of nodes 

   <m> -  number of edges 

   <s> -  identification number of source 

   <t> -  identification number of sink

   <v> <w> <cap>  -      edge (arc) descriptor line

       <v>   - identification number of end or tail node

       <w>   - identification number of end or head node

       <cap> - capacity of edge or arc.
